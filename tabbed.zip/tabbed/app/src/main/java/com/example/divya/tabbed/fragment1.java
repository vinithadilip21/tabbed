package com.example.divya.tabbed;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Set;

/**
 * Created by Divya on 7/23/2018.
 */

public class fragment1 extends Fragment  {
    Button btn;
    Switch wifi, bluetooth, location;
    WifiManager wifiManager;
    TextView wifitext;
    Context context;
    Intent intent1;
    LocationManager locationManager;
    TextView locationtext;
    boolean gpsstatus;
    TextView bluetoothtext;

    BluetoothAdapter bluetoothAdapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view1 = inflater.inflate(R.layout.fragment1_layout, container, false);
        btn = (Button) view1.findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
                startActivity(intent);
            }
        });
        wifiManager = (WifiManager) getActivity().getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        wifi = (Switch) view1.findViewById(R.id.switch1);
        wifitext = (TextView) view1.findViewById(R.id.textView);
        if (wifiManager.isWifiEnabled()) {
            wifitext.setText("WIFI IS CURRENTLY ON");
            wifi.setChecked(true);
        } else {
            wifitext.setText("WIFI IS CURRENTLY OFF");
            wifi.setChecked(false);
        }

        wifi.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    wifiManager.setWifiEnabled(true);
                    wifitext.setText("WIFI IS CURRENTLY ON");
                    Toast.makeText(getActivity(), "wifi may take sometime to turn on", Toast.LENGTH_LONG).show();
                } else {
                    wifiManager.setWifiEnabled(false);
                    wifitext.setText("WIFI IS CURRENTLY OFF");
                }
            }
        });
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        bluetooth = (Switch) view1.findViewById(R.id.switch2);
        bluetoothtext = (TextView) view1.findViewById(R.id.textView2);
        bluetooth.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    bluetoothAdapter.enable();
                    bluetoothtext.setText("BLUETOOTH IS ENABLED");
                } else {
                    bluetoothAdapter.disable();
                    bluetoothtext.setText("BLUETOOTH IS DISABLED");
                }
            }
        });

        location = (Switch) view1.findViewById(R.id.switch3);
        locationtext = (TextView) view1.findViewById(R.id.textView3);


        location.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {


                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    startActivity(intent);

                    locationtext.setText("location is enabled");
                } else {
                    Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                    startActivity(intent);


                    locationtext.setText("Location is disabled");
                }
            }
        });

        return view1;
    }




}
